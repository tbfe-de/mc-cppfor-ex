Adding an interface to the clock
================================

Version of clock-02 using C++98 features only.


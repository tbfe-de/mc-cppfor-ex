Apply "Non-Virtual Interface" Idiom
-----------------------------------

Providing may more extension points for use by derived classes,
"just in case" they might be useful.

Also shows various way for avoiding a loop when counting up by
several steps in a single operation.

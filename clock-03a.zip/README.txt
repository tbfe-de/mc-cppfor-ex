Separate Counting Into Two Classes
----------------------------------

Version of clock-03 using C++98 features only.

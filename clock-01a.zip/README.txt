Example of Clock Build From a Helper Class `Counter`
====================================================

Version of clock-01 using C++98 features only.

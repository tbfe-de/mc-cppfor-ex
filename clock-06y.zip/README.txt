Fill Extension Points Via Template Base Class (version 3)
---------------------------------------------------------

NOTE: All what is said for `clock-06` and `clock-06x` applies
      here too – make sure you read that other `README.txt` too.

The main purpose is a "Cookbook"-Style approach how to extend
"perfect forwarding" for variable length template argument lists.

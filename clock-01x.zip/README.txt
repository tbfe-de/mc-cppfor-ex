Example of clock build from a helper class Counter
==================================================

Some further improvements like

* a non-loop version for counting multiple steps at once
  and
* rudimentary TDD support by allowing an expectation to be
  specified for the expected output via "SHOW_"

The latter is used to easily verify the non-loop version of
`Counter::Count(int)` produces the same output as the much
more simple implementation.

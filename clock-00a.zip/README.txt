Simple example for building a clock
===================================

This is the version of clock-00 using C++98 features only.

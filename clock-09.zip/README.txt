A Clock That Can Tick Up And Down
---------------------------------

At this point a "fresh start" is made by building a `Clock` which
can count up and down.

The former are build based on objects of `UpDownCounter`-s, which
– as their name suggests – supports counting up and down too, not
only when used "stand alone" but also when "chained" together.

Intensive test code is supplied for both classes. (It may also
be useful to understand the intended use of both of the classes.)

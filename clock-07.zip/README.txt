A Clock That Can Tick Up And Down
---------------------------------

At this point a "fresh start" is made by building a `Clock` which
can count up and down, based on an class `UpDownCounter`.

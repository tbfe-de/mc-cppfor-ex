Separate counting into two classes
----------------------------------

Using references instead of pointers to chain the counters.
Adding an interface to the clock
================================

Adding different kinds of clocks and operate them via
the common interface.
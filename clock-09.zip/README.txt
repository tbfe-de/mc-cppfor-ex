Added More Intenive Unit-Testing for `ClockWork`
-----------------------------------------------

(As described of in the `TODO`-s of the previous step.)

Apply "Non-Virtual Interface" Idiom
-----------------------------------

Version of clock-04 using C++98 features only.

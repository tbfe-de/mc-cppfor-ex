Apply NVI-Idiom ("Non-Virtual Interface")
-----------------------------------------

Version of clock-04 using C++98 features only.

"Non-Virtual Interface" Idiom applied extensively
-------------------------------------------------

This solution applies NVI to an extensive degree, providing
MANY extension points, "just in case" a derived class might
need them.

This causes a performance penalty in the form of many calls
to subroutines which return immediately. Obviously these
are a lot of unnecessary instructions executed, less obviously
this reduces the benefits of pipelined instruction caching.


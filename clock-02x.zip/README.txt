Adding an Interface to the Clock
================================

Shows how different clocks can all be operated through that
single interface.

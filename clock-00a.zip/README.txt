Simple Example For Building a Clock
===================================

Version of clock-00 using C++98 features only.

Adding an Interface to the Clock
================================

Version of clock-02 using C++98 features only.


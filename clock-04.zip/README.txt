Apply "Non-Virtual Interface" Idiom
-----------------------------------